import { StorageManager } from '../storage.js';

/* clock.js */
export class Clock {
    constructor(container) {
        this.container = container;
        this.is24Hour = false;
        this.digitMap = {
            '0': [1,1,1,1,1,1,0], '1': [0,1,1,0,0,0,0], '2': [1,1,0,1,1,0,1],
            '3': [1,1,1,1,0,0,1], '4': [0,1,1,0,0,1,1], '5': [1,0,1,1,0,1,1],
            '6': [1,0,1,1,1,1,1], '7': [1,1,1,0,0,0,0], '8': [1,1,1,1,1,1,1],
            '9': [1,1,1,1,0,1,1], ' ': [0,0,0,0,0,0,0]
        };
        this.segments = [];
        this.lastTime = "";
        this.init();
    }

    async init() {
        //[cite: 2]
        const formatPref = await StorageManager.getPref('clock_format', '12');
        this.is24Hour = formatPref === '24';

        this.element = document.createElement('div');
        this.element.className = 'clock-widget';
        
        // Header bar (Date and mini-time)
        this.header = document.createElement('div');
        this.header.className = 'clock-header';
        this.element.appendChild(this.header);

        // Digits container
        this.digitsContainer = document.createElement('div');
        this.digitsContainer.className = 'clock-digits';
        
        for(let i=0; i<4; i++) {
            const digit = this.createDigit();
            this.segments.push(digit.nodes);
            this.digitsContainer.appendChild(digit.container);
        }
        this.element.appendChild(this.digitsContainer);

        this.container.appendChild(this.element);
        this.element.addEventListener('click', () => this.toggleFormat());
        
        // Use requestAnimationFrame for smooth UI sync[cite: 2]
        const tick = () => {
            this.updateTime();
            requestAnimationFrame(tick);
        };
        tick();
    }

    createDigit() {
        const div = document.createElement('div');
        div.className = 'digit-container';
        const classes = ['a', 'b', 'c', 'd', 'e', 'f', 'g'];
        const nodes = classes.map(c => {
            const seg = document.createElement('div');
            seg.className = `segment seg-${c}`;
            div.appendChild(seg);
            return seg;
        });
        return { container: div, nodes };
    }

    updateTime() {
        const now = new Date();
        
        // Update Header (Thu 30 Apr 10:10)
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const dayName = days[now.getDay()];
        const day = now.getDate();
        const month = months[now.getMonth()];
        const hoursMini = now.getHours().toString().padStart(2, '0');
        const minutesMini = now.getMinutes().toString().padStart(2, '0');
        
        if (this.header) {
            this.header.innerHTML = `${dayName} ${day} ${month} <span class="clock-icon">🕒</span> ${hoursMini}:${minutesMini}`;
        }

        let h = now.getHours();
        const m = now.getMinutes().toString().padStart(2, '0');
        
        if (!this.is24Hour) h = h % 12 || 12;
        const timeStr = h.toString().padStart(2, ' ').slice(-2) + m;
        
        if (timeStr === this.lastTime) return;
        this.lastTime = timeStr;

        timeStr.split('').forEach((char, dIdx) => {
            const pattern = this.digitMap[char];
            this.segments[dIdx].forEach((segNode, sIdx) => {
                // Performant class toggle[cite: 2]
                segNode.classList.toggle('on', !!pattern[sIdx]);
            });
        });
    }

    async toggleFormat() {
        this.is24Hour = !this.is24Hour;
        await StorageManager.setPref('clock_format', this.is24Hour ? '24' : '12'); //[cite: 2]
    }
}
